const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { spawn, execSync } = require('child_process');

const CONFIG_FILE = path.join(__dirname, '..', 'playit-sftp.json');
const BIN_DIR = path.join(__dirname, '..', 'bin');

let playitProcess = null;
let currentClaimUrl = null;
let detectedHost = null;
let detectedPort = null;
let lastError = null;

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    }
  } catch (e) {}
  return {
    enabled: false,
    customHost: '',
    customPort: null,
    secretKey: '',
    autoStart: false
  };
}

function saveConfig(cfg) {
  try {
    const current = loadConfig();
    const updated = { ...current, ...cfg };
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(updated, null, 2), 'utf8');
    return updated;
  } catch (e) {
    console.error('[Playit SFTP] Failed to save config:', e.message);
    return loadConfig();
  }
}

function getBinaryInfo() {
  const platform = process.platform;
  const arch = process.arch;

  if (platform === 'win32') {
    return {
      filename: 'playit.exe',
      url: 'https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-win-x86_64.exe'
    };
  } else if (platform === 'linux') {
    if (arch === 'arm64') {
      return {
        filename: 'playit',
        url: 'https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-linux-arm64'
      };
    }
    return {
      filename: 'playit',
      url: 'https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-linux-amd64'
    };
  } else if (platform === 'darwin') {
    return {
      filename: 'playit',
      url: 'https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-darwin-amd64'
    };
  }

  return {
    filename: process.platform === 'win32' ? 'playit.exe' : 'playit',
    url: 'https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-linux-amd64'
  };
}

function getBinaryPath() {
  const info = getBinaryInfo();
  return path.join(BIN_DIR, info.filename);
}

function isBinaryDownloaded() {
  const binPath = getBinaryPath();
  return fs.existsSync(binPath);
}

function downloadBinaryProgress(onProgress) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(BIN_DIR)) {
      fs.mkdirSync(BIN_DIR, { recursive: true });
    }

    const binPath = getBinaryPath();
    const info = getBinaryInfo();

    console.log(`[Playit SFTP] Downloading playit binary from ${info.url} to ${binPath}...`);

    function fetchUrl(url, redirects = 0) {
      if (redirects > 10) {
        return reject(new Error('Too many redirects while downloading Playit binary'));
      }

      const client = url.startsWith('https') ? https : http;
      client.get(url, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          return fetchUrl(res.headers.location, redirects + 1);
        }

        if (res.statusCode !== 200) {
          return reject(new Error(`Failed to download Playit binary: HTTP ${res.statusCode}`));
        }

        const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
        let downloadedBytes = 0;
        const fileStream = fs.createWriteStream(binPath);

        res.on('data', (chunk) => {
          downloadedBytes += chunk.length;
          fileStream.write(chunk);
          if (totalBytes > 0 && typeof onProgress === 'function') {
            const percent = Math.round((downloadedBytes / totalBytes) * 100);
            onProgress(percent, downloadedBytes, totalBytes);
          }
        });

        res.on('end', () => {
          fileStream.end();
          if (process.platform !== 'win32') {
            try {
              fs.chmodSync(binPath, 0o755);
            } catch (e) {}
          }
          console.log('[Playit SFTP] Playit binary downloaded successfully');
          resolve(binPath);
        });

        res.on('error', (err) => {
          fileStream.end();
          try { fs.unlinkSync(binPath); } catch (e) {}
          reject(err);
        });
      }).on('error', (err) => {
        reject(err);
      });
    }

    fetchUrl(info.url);
  });
}

function startPlayit() {
  return new Promise(async (resolve, reject) => {
    if (playitProcess) {
      return resolve(getStatus());
    }

    const binPath = getBinaryPath();
    if (!fs.existsSync(binPath)) {
      try {
        console.log('[Playit SFTP] Binary missing, auto-downloading...');
        await downloadBinaryProgress();
      } catch (err) {
        lastError = 'Download failed: ' + err.message;
        return reject(err);
      }
    }

    const config = loadConfig();

    // Write secret_key to playit.toml if specified
    if (config.secretKey && config.secretKey.trim()) {
      try {
        const tomlPath = path.join(__dirname, '..', 'playit.toml');
        const tomlContent = `secret_key = "${config.secretKey.trim()}"\n`;
        fs.writeFileSync(tomlPath, tomlContent, 'utf8');
      } catch (e) {
        console.warn('[Playit SFTP] Could not write playit.toml:', e.message);
      }
    }

    console.log('[Playit SFTP] Spawning playit agent process...');
    lastError = null;
    currentClaimUrl = null;

    try {
      const spawnOpts = {
        cwd: path.join(__dirname, '..'),
        env: { ...process.env }
      };

      playitProcess = spawn(binPath, ['--secret', config.secretKey || ''], spawnOpts);

      let stdoutBuffer = '';

      playitProcess.stdout.on('data', (data) => {
        const str = data.toString();
        stdoutBuffer += str;
        console.log('[Playit stdout]', str.trim());

        // Check for claim URL
        const claimMatch = str.match(/https:\/\/playit\.gg\/claim\/[a-zA-Z0-9-]+/i) ||
                           str.match(/https:\/\/playit\.gg\/account\/claim\/[a-zA-Z0-9-]+/i);
        if (claimMatch) {
          currentClaimUrl = claimMatch[0];
          console.log('[Playit SFTP] Claim URL:', currentClaimUrl);
        }

        // Check for tunnel address: e.g. "sftp-123.playit.gg:2222" or IP:port or "147.185.221.16:12345"
        const tunnelMatch = str.match(/([a-zA-Z0-9.-]+\.playit\.gg|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{2,5})/i);
        if (tunnelMatch) {
          detectedHost = tunnelMatch[1];
          detectedPort = parseInt(tunnelMatch[2], 10);
          console.log(`[Playit SFTP] Tunnel detected: ${detectedHost}:${detectedPort}`);
        }
      });

      playitProcess.stderr.on('data', (data) => {
        const str = data.toString();
        console.log('[Playit stderr]', str.trim());
      });

      playitProcess.on('error', (err) => {
        console.error('[Playit SFTP] Process error:', err.message);
        lastError = err.message;
        playitProcess = null;
      });

      playitProcess.on('exit', (code, signal) => {
        console.log(`[Playit SFTP] Process exited with code ${code}, signal ${signal}`);
        playitProcess = null;
      });

      // Mark enabled in config
      saveConfig({ enabled: true });

      // Give it 1.5 seconds to spin up
      setTimeout(() => {
        resolve(getStatus());
      }, 1500);

    } catch (err) {
      lastError = err.message;
      playitProcess = null;
      reject(err);
    }
  });
}

function stopPlayit() {
  if (playitProcess) {
    try {
      playitProcess.kill('SIGTERM');
    } catch (e) {}
    playitProcess = null;
  }
  saveConfig({ enabled: false });
  return getStatus();
}

function getStatus() {
  const config = loadConfig();
  const isRunning = !!playitProcess;
  const binDownloaded = isBinaryDownloaded();

  const host = config.customHost ? config.customHost : (detectedHost || null);
  const port = config.customPort ? config.customPort : (detectedPort || null);

  return {
    enabled: config.enabled,
    running: isRunning,
    binaryDownloaded: binDownloaded,
    claimUrl: currentClaimUrl,
    host: host,
    port: port,
    customHost: config.customHost,
    customPort: config.customPort,
    secretKey: config.secretKey,
    lastError: lastError,
    pid: playitProcess ? playitProcess.pid : null
  };
}

// Auto-start if config.autoStart || config.enabled is true on panel boot
function autoStartIfEnabled() {
  const config = loadConfig();
  if (config.enabled || config.autoStart) {
    console.log('[Playit SFTP] Auto-starting Playit SFTP tunnel...');
    startPlayit().catch(err => {
      console.warn('[Playit SFTP] Auto-start failed:', err.message);
    });
  }
}

module.exports = {
  loadConfig,
  saveConfig,
  downloadBinaryProgress,
  isBinaryDownloaded,
  startPlayit,
  stopPlayit,
  getStatus,
  autoStartIfEnabled
};
