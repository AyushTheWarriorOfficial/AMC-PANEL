const crypto = require('crypto');

// In-memory token store (with timestamp indexing for fast cleanup)
const tokenStore = new Map();

// Rate limiting map per userId (max 10 token generations per 5 minutes)
const rateLimits = new Map();

function isRateLimited(userId) {
  const now = Date.now();
  const userLogs = rateLimits.get(userId) || [];
  const validLogs = userLogs.filter(ts => now - ts < 5 * 60 * 1000);
  rateLimits.set(userId, validLogs);
  if (validLogs.length >= 10) {
    return true;
  }
  validLogs.push(now);
  return false;
}

function isTailscaleIp(ip) {
  if (!ip) return false;
  const cleanIp = ip.replace(/^::ffff:/, '').trim();
  // Tailscale IPv4 CGNAT range: 100.64.0.0 to 100.127.255.255
  if (cleanIp.startsWith('100.')) {
    const parts = cleanIp.split('.').map(Number);
    if (parts.length === 4 && parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127) {
      return true;
    }
  }
  // Local loopback or localhost for testing
  if (cleanIp === '127.0.0.1' || cleanIp === '::1' || cleanIp === 'localhost') {
    return true;
  }
  return false;
}

function generateToken(userId, serverId, ttlMinutes = 15) {
  if (isRateLimited(userId)) {
    throw new Error('Rate limit exceeded. Please wait a few minutes before generating a new link.');
  }

  // Revoke any existing pending tokens for this user & server
  for (const [t, data] of tokenStore.entries()) {
    if (data.userId === userId && data.serverId == serverId && data.status === 'pending') {
      data.status = 'revoked';
    }
  }

  // Generate 32-char hex token (128 bits entropy)
  const token = crypto.randomBytes(16).toString('hex');
  const now = Date.now();
  const expiresAt = now + ttlMinutes * 60 * 1000;

  const tokenData = {
    token,
    userId,
    serverId: parseInt(serverId, 10),
    createdAt: now,
    expiresAt,
    status: 'pending', // 'pending' | 'connected' | 'expired' | 'revoked'
    clientIp: null,
    tailscaleIp: null,
    verifiedAt: null
  };

  tokenStore.set(token, tokenData);
  console.log(`[Tailscale Audit] Token generated for user ${userId}, server ${serverId} (Token: ${token.substring(0, 8)}...)`);
  return tokenData;
}

function getToken(token) {
  if (!tokenStore.has(token)) return null;
  const data = tokenStore.get(token);
  
  if (data.status === 'pending' && Date.now() > data.expiresAt) {
    data.status = 'expired';
  }
  return data;
}

function verifyAndConnectDevice(token, requestIp) {
  const data = getToken(token);
  if (!data) {
    return { success: false, error: 'Invalid connection token' };
  }

  if (data.status === 'expired' || Date.now() > data.expiresAt) {
    data.status = 'expired';
    return { success: false, error: 'Connection token has expired' };
  }

  if (data.status === 'revoked') {
    return { success: false, error: 'Connection token was revoked' };
  }

  const cleanIp = (requestIp || '').replace(/^::ffff:/, '').trim();
  const isTs = isTailscaleIp(cleanIp);

  // Update token status
  data.status = 'connected';
  data.clientIp = cleanIp;
  data.tailscaleIp = isTs ? cleanIp : null;
  data.verifiedAt = Date.now();

  console.log(`[Tailscale Audit] Device verified & connected for token ${token.substring(0, 8)}... (IP: ${cleanIp}, Tailscale: ${isTs})`);
  return { success: true, tokenData: data, isTailscaleIp: isTs };
}

function revokeToken(token, userId) {
  const data = getToken(token);
  if (!data) return false;
  if (data.userId !== userId) {
    throw new Error('Unauthorized to revoke this token');
  }
  data.status = 'revoked';
  console.log(`[Tailscale Audit] Token revoked by user ${userId} (Token: ${token.substring(0, 8)}...)`);
  return true;
}

function revokeServerTokens(userId, serverId) {
  let count = 0;
  for (const [t, data] of tokenStore.entries()) {
    if (data.userId === userId && data.serverId == serverId) {
      data.status = 'revoked';
      count++;
    }
  }
  return count;
}

// Cleanup expired tokens every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [t, data] of tokenStore.entries()) {
    if (data.expiresAt < now - 60 * 60 * 1000) { // purge after 1 hr of expiry
      tokenStore.delete(t);
    }
  }
}, 5 * 60 * 1000);

module.exports = {
  generateToken,
  getToken,
  verifyAndConnectDevice,
  revokeToken,
  revokeServerTokens,
  isTailscaleIp
};
