const fs = require('fs');
const path = require('path');
const { exec, execSync } = require('child_process');

const CONFIG_FILE = path.join(__dirname, '..', 'tailscale-sftp.json');

let currentStatus = {
  enabled: false,
  running: false,
  ip: null,
  nodeName: null,
  customHost: '',
  lastCheck: null,
  error: null
};

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    }
  } catch (e) {}
  return {
    enabled: true,
    customHost: '',
    autoStart: true
  };
}

function saveConfig(cfg) {
  try {
    const current = loadConfig();
    const updated = { ...current, ...cfg };
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(updated, null, 2), 'utf8');
    return updated;
  } catch (e) {
    console.error('[Tailscale SFTP] Failed to save config:', e.message);
    return loadConfig();
  }
}

function getTailscaleCliPath() {
  if (process.platform === 'win32') {
    const defaultWinPath = 'C:\\Program Files\\Tailscale\\tailscale.exe';
    if (fs.existsSync(defaultWinPath)) {
      return `"${defaultWinPath}"`;
    }
  }
  return 'tailscale';
}

function detectTailscaleInfo() {
  return new Promise((resolve) => {
    const cli = getTailscaleCliPath();
    exec(`${cli} status --json`, (err, stdout, stderr) => {
      if (!err && stdout) {
        try {
          const json = JSON.parse(stdout);
          const self = json.Self || {};
          let tsIp = null;
          if (Array.isArray(self.TailscaleIPs)) {
            tsIp = self.TailscaleIPs.find(ip => ip.includes('.')) || self.TailscaleIPs[0];
          }
          const nodeName = self.DNSName ? self.DNSName.replace(/\.$/, '') : (self.HostName || null);
          const isOnline = json.BackendState === 'Running' || self.Online === true;
          
          currentStatus.running = isOnline;
          currentStatus.ip = tsIp;
          currentStatus.nodeName = nodeName;
          currentStatus.error = null;
          currentStatus.lastCheck = new Date();
          return resolve(currentStatus);
        } catch (e) {}
      }

      // Fallback: try `tailscale ip -4`
      exec(`${cli} ip -4`, (ipErr, ipStdout) => {
        if (!ipErr && ipStdout && ipStdout.trim()) {
          const cleanIp = ipStdout.trim().split('\n')[0].trim();
          currentStatus.running = true;
          currentStatus.ip = cleanIp;
          currentStatus.error = null;
          currentStatus.lastCheck = new Date();
          return resolve(currentStatus);
        }

        currentStatus.running = false;
        currentStatus.ip = null;
        currentStatus.nodeName = null;
        currentStatus.error = 'Tailscale process or CLI not connected';
        currentStatus.lastCheck = new Date();
        return resolve(currentStatus);
      });
    });
  });
}

async function getStatus() {
  const cfg = loadConfig();
  await detectTailscaleInfo();
  
  const host = cfg.customHost && cfg.customHost.trim() !== ''
    ? cfg.customHost.trim()
    : (currentStatus.ip || currentStatus.nodeName || 'Not Connected');

  return {
    enabled: cfg.enabled !== false,
    running: currentStatus.running,
    ip: currentStatus.ip,
    nodeName: currentStatus.nodeName,
    customHost: cfg.customHost || '',
    host: host,
    port: 2222,
    error: currentStatus.error,
    lastCheck: currentStatus.lastCheck
  };
}

async function startTailscale() {
  const cfg = loadConfig();
  cfg.enabled = true;
  saveConfig(cfg);

  return new Promise((resolve) => {
    const cli = getTailscaleCliPath();
    exec(`${cli} up`, (err) => {
      detectTailscaleInfo().then(() => resolve(getStatus()));
    });
  });
}

async function stopTailscale() {
  const cfg = loadConfig();
  cfg.enabled = false;
  saveConfig(cfg);
  return getStatus();
}

// Auto-initialize
detectTailscaleInfo();

module.exports = {
  getStatus,
  startTailscale,
  stopTailscale,
  saveConfig,
  loadConfig
};
